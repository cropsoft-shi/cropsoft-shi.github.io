Web Bluetooth Samples
=====================

See https://googlechrome.github.io/samples/web-bluetooth/index.html to browse all Web Bluetooth samples.

Learn more at https://www.chromestatus.com/feature/5264933985976320
