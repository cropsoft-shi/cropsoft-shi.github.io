CSS Custom Properties (CSS Variables) Sample
===
See https://googlechrome.github.io/samples/css-custom-properties/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6401356696911872
