Sequential Focus Navigation Start Point Sample
===

See https://googlechrome.github.io/samples/focus-navigation-start-point/index.html for a live demo.

Learn more at https://www.chromestatus.com/features/5671747802103808
