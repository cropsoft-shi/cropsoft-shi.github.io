Collections and Iterators (ES6) Sample
===
See https://googlechrome.github.io/samples/collections-iterators-es6/index.html for a live demo.

Learn more about:
  - [for...of Iterators](https://www.chromestatus.com/feature/4696563918045184)
  - [Maps](https://www.chromestatus.com/feature/4818609708728320)
  - [Sets](https://www.chromestatus.com/feature/4916191365693440)
