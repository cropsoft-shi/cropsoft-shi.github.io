Cookie Prefixes Sample
===
See https://googlechrome.github.io/samples/cookie-prefixes/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/4952188392570880
