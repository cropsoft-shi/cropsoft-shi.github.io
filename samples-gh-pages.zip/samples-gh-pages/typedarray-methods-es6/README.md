TypedArray Methods (ECMAScript 2015) Sample
===========================================
See https://googlechrome.github.io/samples/typedarray-methods-es6/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/4919908559224832
