Cut and Copy Sample
===
See https://googlechrome.github.io/samples/cut-and-copy/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5223997243392000