Web Animations Sample
===
See https://googlechrome.github.io/samples/web-animations/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/4854343836631040