Spread Calls Sample
===
See https://googlechrome.github.io/samples/spread-operator/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6031334694715392
