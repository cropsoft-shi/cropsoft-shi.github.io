Force Flattening When Ancestor Has Opacity Sample
=================================================
See https://googlechrome.github.io/samples/css-opacity-force-flattening/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5671480339726336
