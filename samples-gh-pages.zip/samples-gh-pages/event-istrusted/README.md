Event.isTrusted Sample
======================

See https://googlechrome.github.io/samples/event-istrusted/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6461137440735232
