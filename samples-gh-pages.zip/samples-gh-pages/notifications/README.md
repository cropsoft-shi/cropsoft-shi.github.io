Notification API Samples
===

Samples for various Notification options

vibrate
====
[Live demo](https://googlechrome.github.io/samples/notifications/vibrate.html)

Learn more at https://www.chromestatus.com/feature/5727996321202176

requireInteraction
====
[Live demo](https://googlechrome.github.io/samples/notifications/requireInteraction.html)

Learn more at https://www.chromestatus.com/feature/5641440986136576
