Presentation API Sample
===
See https://googlechrome.github.io/samples/presentation-api/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6676265876586496
