Image Capture Samples
===
See https://googlechrome.github.io/samples/image-capture/index.html to browse all Image Capture samples.  

Learn more at https://www.chromestatus.com/features/4843864737185792
