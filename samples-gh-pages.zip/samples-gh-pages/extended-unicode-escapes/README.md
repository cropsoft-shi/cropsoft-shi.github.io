Extended Unicode Escapes in Strings Sample
===
See https://googlechrome.github.io/samples/extended-unicode-escapes/index.html for a live demo.
