Array.of('hello');      // ["hello"]
Array.of(1, 2, 3);      // [1, 2, 3]
Array.of('blink', 182); // ["blink", 182]
