[0, 1, 2, 3, 4].copyWithin(target=4, start=0); // [0, 1, 2, 3, 0]
[0, 1, 2, 3, 4].copyWithin(target=0, start=2); // [2, 3, 4, 3, 4]
