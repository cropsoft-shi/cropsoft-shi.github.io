[0, 1, 2, 3, 4].copyWithin(target=0, start=3, end=4);  // [3, 1, 2, 3, 4]
[0, 1, 2, 3, 4].copyWithin(target=0, start=-2, end=-1); // [3, 1, 2, 3, 4]
