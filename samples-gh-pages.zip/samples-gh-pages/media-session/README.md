Media Session Sample
===
See https://googlechrome.github.io/samples/media-session/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5639924124483584
