IndexedDB observer Sample
===
See https://googlechrome.github.io/samples/indexeddb-observers/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5669292892749824
