/*
  This service worker doesn't actually do anything!

  In the real world, you would add support for Offline or the ability to
  handle push messages.
*/
