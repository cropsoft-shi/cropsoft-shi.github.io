ES6 Computed Property Names
===
