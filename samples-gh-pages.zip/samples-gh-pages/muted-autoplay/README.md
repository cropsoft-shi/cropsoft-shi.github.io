Muted Autoplay Sample
=====================
See https://googlechrome.github.io/samples/muted-autoplay/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/4864052794753024
