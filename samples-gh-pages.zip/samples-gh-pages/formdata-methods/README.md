FormData methods for inspection and modification Sample
===
See https://googlechrome.github.io/samples/formdata-methods/index.html for a live demo.

For a full list of methods, see https://developer.mozilla.org/en/docs/Web/API/FormData

Learn more at https://www.chromestatus.com/feature/5701572055007232
