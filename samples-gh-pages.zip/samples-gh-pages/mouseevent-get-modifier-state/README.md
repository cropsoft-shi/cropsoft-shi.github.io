MouseEvent.getModifierState() Sample
===
See https://googlechrome.github.io/samples/mouseevent-get-modifier-state/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5662574238498816
