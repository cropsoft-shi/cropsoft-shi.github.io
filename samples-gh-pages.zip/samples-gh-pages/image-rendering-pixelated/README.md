Pixelated Image Rendering Sample
===

See https://googlechrome.github.io/samples/image-rendering-pixelated/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5118058116939776