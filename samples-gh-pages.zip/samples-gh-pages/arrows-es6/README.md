Arrow functions (ES6) Sample
===
See https://googlechrome.github.io/samples/arrows-es6/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5047308127305728
