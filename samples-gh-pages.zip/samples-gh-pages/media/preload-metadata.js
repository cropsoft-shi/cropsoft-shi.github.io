const videowithNoPreload = document.querySelector('#videoWithNoPreload');
const videowithAutoPreload = document.querySelector('#videoWithNoPreload');

log('               <video> preload value is ' + videoWithNoPreload.preload);
log('<video preload="auto"> preload value is ' + videoWithAutoPreload.preload);
