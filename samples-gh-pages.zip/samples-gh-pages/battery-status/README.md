Battery Status Sample
=====================

See https://googlechrome.github.io/samples/battery-status for a live demo.

Learn more at https://www.chromestatus.com/feature/4537134732017664
