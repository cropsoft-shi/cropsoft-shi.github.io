Picture Element Sample
===
See https://googlechrome.github.io/samples/picture-element for a live demo.

Learn more at https://www.chromestatus.com/feature/5910974510923776
