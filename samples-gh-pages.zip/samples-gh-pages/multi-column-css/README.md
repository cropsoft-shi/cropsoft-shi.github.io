Multi-column CSS Sample
===
See https://googlechrome.github.io/samples/multi-column-css/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6526151266664448
