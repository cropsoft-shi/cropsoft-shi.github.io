Array Method includes (ES7) Sample
==================================
See https://googlechrome.github.io/samples/array-includes-es7/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5964420647747584
