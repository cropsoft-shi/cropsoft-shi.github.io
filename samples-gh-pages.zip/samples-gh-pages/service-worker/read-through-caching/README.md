Service Worker Sample: Read-through Caching
===
See https://googlechrome.github.io/samples/service-worker/read-through-caching/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6561526227927040
