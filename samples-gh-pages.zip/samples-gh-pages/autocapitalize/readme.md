Auto Capitalize
===

See https://googlechrome.github.io/samples/autocapitalize/index.html for a live demo.
