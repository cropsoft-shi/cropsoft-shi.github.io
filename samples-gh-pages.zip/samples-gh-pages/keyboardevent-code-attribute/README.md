KeyboardEvent code Attribute Sample
===
See https://googlechrome.github.io/samples/keyboardevent-code-attribute/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5228092293382144
