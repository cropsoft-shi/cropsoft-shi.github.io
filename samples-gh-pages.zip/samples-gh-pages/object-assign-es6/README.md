Object.assign() (ES6) Sample
===
See https://googlechrome.github.io/samples/object-assign-es6/index.html for a live demo.

<!-- TODO: Replace PLACEHOLDER with the id from the chromestatus.com URL. -->
<!--Learn more at https://www.chromestatus.com/feature/PLACEHOLDER-->
